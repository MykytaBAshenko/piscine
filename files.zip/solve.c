/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solve.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: login <login@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/10/12 12:00:00 by login             #+#    #+#             */
/*   Updated: 2026/10/12 12:00:00 by login            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

static size_t	min3(size_t a, size_t b, size_t c)
{
	if (b < a)
		a = b;
	if (c < a)
		a = c;
	return (a);
}

static size_t	cell_val(t_map *m, size_t *rows, size_t i, size_t j)
{
	size_t	*cur;
	size_t	*prev;
	size_t	left;
	size_t	diag;

	if (m->data[m->start + i * (m->w + 1) + j] == m->o)
		return (0);
	cur = rows + (i % 2) * m->w;
	prev = rows + ((i + 1) % 2) * m->w;
	left = 0;
	diag = 0;
	if (j > 0)
	{
		left = cur[j - 1];
		diag = prev[j - 1];
	}
	return (min3(left, diag, prev[j]) + 1);
}

static void	do_row(t_map *m, size_t *rows, size_t i, t_best *b)
{
	size_t	j;
	size_t	*cur;

	cur = rows + (i % 2) * m->w;
	j = 0;
	while (j < m->w)
	{
		cur[j] = cell_val(m, rows, i, j);
		if (cur[j] > b->size)
		{
			b->size = cur[j];
			b->row = i;
			b->col = j;
		}
		j++;
	}
}

static void	fill(t_map *m, t_best *b)
{
	size_t	i;
	size_t	j;
	size_t	base;

	base = m->start + b->row * (m->w + 1) + b->col;
	i = 0;
	while (i < b->size)
	{
		j = 0;
		while (j < b->size)
		{
			m->data[base - i * (m->w + 1) - j] = m->f;
			j++;
		}
		i++;
	}
}

int	solve(t_map *m)
{
	size_t	*rows;
	size_t	i;
	t_best	best;

	rows = malloc(sizeof(size_t) * m->w * 2);
	if (!rows)
		return (0);
	i = 0;
	while (i < m->w * 2)
	{
		rows[i] = 0;
		i++;
	}
	best.size = 0;
	best.row = 0;
	best.col = 0;
	i = 0;
	while (i < (size_t)m->n)
	{
		do_row(m, rows, i, &best);
		i++;
	}
	free(rows);
	fill(m, &best);
	return (1);
}
